Sample: magnetic adatom chains on a superconductor
Scan mode: constant current
